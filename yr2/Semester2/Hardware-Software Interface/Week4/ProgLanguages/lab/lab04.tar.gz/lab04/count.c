#include <stdio.h>

/* Counts how many characters are in the `fin` file */
int count(FILE * fin)
{
    int chars = 0;

    while (1) {
        int ch;

        /* TODO: get the next character into ch */

        /* TODO: if end of file was reached (ch == EOF), exit the loop */

        /* TODO: increment chars */
    }

    return chars;
}

int main(int argc, char *argv[])
{
    FILE *fin;

    /* TODO: check that argc is correct */

    /* TODO: open file, using the filename from the 1st command argument */

    /* TODO: check that the file was opened successfully (fin != NULL) */

    /* TODO: call count with the opened file, and print the result */

    /* TODO: close the file */

    return 0;
}
