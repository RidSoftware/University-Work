# F28HS Coursework 1


# Task
H00402826: HS8 MEDIAN NORM

# Compile
gcc process.c -o process -std=c99 -O2 -Wall -pedantic -g

# Run
./process INPUTFILE OUTPUTFILE
    files are the relative paths to the file